package com.geminimod;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.BipedArmorLayer;
import net.minecraft.client.renderer.entity.layers.HeldItemLayer;
import net.minecraft.client.renderer.entity.model.BipedModel;
import net.minecraft.util.ResourceLocation;

public class GeminiRenderer extends MobRenderer<GeminiEntity, BipedModel<GeminiEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(GeminiMod.MODID, "textures/entity/gemini.png");

    public GeminiRenderer(EntityRendererManager manager) {
        super(manager, new BipedModel<GeminiEntity>(0.0F), 0.5F);
        this.addLayer(new HeldItemLayer<GeminiEntity, BipedModel<GeminiEntity>>(this));
        this.addLayer(new BipedArmorLayer<GeminiEntity, BipedModel<GeminiEntity>, BipedModel<GeminiEntity>>(
                this, new BipedModel<GeminiEntity>(0.5F), new BipedModel<GeminiEntity>(1.0F)));
    }

    @Override
    public ResourceLocation getTextureLocation(GeminiEntity entity) {
        return TEXTURE;
    }
}
