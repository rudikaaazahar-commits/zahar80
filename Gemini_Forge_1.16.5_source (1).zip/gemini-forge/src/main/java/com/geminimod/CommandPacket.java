package com.geminimod;

import java.util.function.Supplier;

import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

public class CommandPacket {
    public final int cmd;

    public CommandPacket(int cmd) {
        this.cmd = cmd;
    }

    public static void encode(CommandPacket p, PacketBuffer buf) {
        buf.writeInt(p.cmd);
    }

    public static CommandPacket decode(PacketBuffer buf) {
        return new CommandPacket(buf.readInt());
    }

    public static void handle(CommandPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayerEntity player = ctx.get().getSender();
            if (player != null) {
                GeminiCommands.run(player, p.cmd);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
