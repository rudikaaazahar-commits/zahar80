package com.geminimod;

import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

@Mod(GeminiMod.MODID)
public class GeminiMod {
    public static final String MODID = "geminimod";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<EntityType<GeminiEntity>> GEMINI = ENTITIES.register("gemini",
            () -> EntityType.Builder.of(GeminiEntity::new, EntityClassification.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(10)
                    .build(MODID + ":gemini"));

    public static final RegistryObject<Item> GEMINI_SPAWN_EGG = ITEMS.register("gemini_spawn_egg",
            () -> new ForgeSpawnEggItem(GEMINI, 0x4285F4, 0x9B72F2,
                    new Item.Properties().tab(ItemGroup.TAB_MISC)));

    public GeminiMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(this::onAttributes);
        modBus.addListener(this::onCommonSetup);
    }

    private void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Net::init);
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(GEMINI.get(), GeminiEntity.createAttributes().build());
    }
}
