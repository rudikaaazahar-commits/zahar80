package com.geminimod;

import java.util.HashSet;
import java.util.Set;

import net.minecraft.entity.AgeableEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.goal.HurtByTargetGoal;
import net.minecraft.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.entity.ai.goal.LookAtGoal;
import net.minecraft.entity.ai.goal.LookRandomlyGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.ai.goal.OwnerHurtByTargetGoal;
import net.minecraft.entity.ai.goal.OwnerHurtTargetGoal;
import net.minecraft.entity.ai.goal.SitGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WaterAvoidingRandomWalkingGoal;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class GeminiEntity extends TameableEntity {

    private static final String PREFIX = "\u00a7b<Gemini>\u00a7r ";
    private static final String[] PHRASES = {
            "Привіт! Я тут, граємо разом!",
            "Бачу ворогів - я тебе прикрию!",
            "Може збудуємо щось класне?",
            "Давай шукати алмази!",
            "Ти найкращий гравець, якого я знаю!",
            "Обережно з кріпером!",
            "Я з тобою до кінця гри!",
            "Нічого не зламав? Тоді йдемо далі!"
    };

    private int talkTimer = 600;

    /** Стан копання (використовує MineGoal). */
    public BlockPos mineTarget = null;
    public boolean oreMode = false;
    public final Set<BlockPos> badTargets = new HashSet<>();

    public void stopMining() {
        this.mineTarget = null;
        this.oreMode = false;
    }

    public GeminiEntity(EntityType<? extends TameableEntity> type, World world) {
        super(type, world);
    }

    public static AttributeModifierMap.MutableAttribute createAttributes() {
        return MobEntityAttributes();
    }

    private static AttributeModifierMap.MutableAttribute MobEntityAttributes() {
        return net.minecraft.entity.MobEntity.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new SwimGoal(this));
        this.goalSelector.addGoal(1, new SitGoal(this));
        this.goalSelector.addGoal(1, new MineGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(3, new FollowOwnerGoal(this, 1.1D, 8.0F, 3.0F, false));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomWalkingGoal(this, 0.8D));
        this.goalSelector.addGoal(5, new LookAtGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.addGoal(6, new LookRandomlyGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this).setAlertOthers());
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, MonsterEntity.class,
                10, true, false, e -> this.isTame() && !(e instanceof CreeperEntity)));
    }

    @Override
    public ActionResultType mobInteract(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!this.isTame() && stack.getItem() == Items.DIAMOND) {
            if (!this.level.isClientSide) {
                if (!player.abilities.instabuild) {
                    stack.shrink(1);
                }
                this.tame(player);
                this.navigation.stop();
                this.setTarget(null);
                this.level.broadcastEntityEvent(this, (byte) 7);
                player.sendMessage(new StringTextComponent(PREFIX + "Ура! Тепер ми друзі! Граємо разом!"), Util.NIL_UUID);
            }
            return ActionResultType.sidedSuccess(this.level.isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!this.level.isClientSide && this.isTame() && --this.talkTimer <= 0) {
            this.talkTimer = 800 + this.random.nextInt(1200);
            LivingEntity owner = this.getOwner();
            if (owner instanceof PlayerEntity) {
                String phrase = PHRASES[this.random.nextInt(PHRASES.length)];
                owner.sendMessage(new StringTextComponent(PREFIX + phrase), Util.NIL_UUID);
            }
        }
    }

    /** Команда "атакуй": ціль - найближчий ворог (крім кріперів) у 20 блоках. */
    public boolean attackNearest() {
        MonsterEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (MonsterEntity m : this.level.getEntitiesOfClass(MonsterEntity.class, this.getBoundingBox().inflate(20.0D))) {
            if (m instanceof CreeperEntity || !m.isAlive()) continue;
            double d = this.distanceToSqr(m);
            if (d < bestDist) { bestDist = d; best = m; }
        }
        if (best == null) return false;
        this.setOrderedToSit(false);
        this.setTarget(best);
        return true;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    @Override
    public AgeableEntity getBreedOffspring(ServerWorld world, AgeableEntity mate) {
        return null;
    }
}
