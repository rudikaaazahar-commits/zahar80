package com.geminimod;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.text.IFormattableTextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;

public class GeminiCommands {
    public static final int FOLLOW = 0;
    public static final int STAY = 1;
    public static final int COME = 2;
    public static final int ATTACK = 3;
    public static final int GIVE_ITEM = 4;
    public static final int TAKE_BACK = 5;
    public static final int FIND_ORES = 6;
    public static final int MINE_ORES = 7;
    public static final int MINE_LOOKED = 8;
    public static final int STOP_MINING = 9;

    public static final String PREFIX = "\u00a7b<Gemini>\u00a7r ";

    public static void say(ServerPlayerEntity player, String text) {
        player.sendMessage(new StringTextComponent(PREFIX + text), Util.NIL_UUID);
    }

    /** Знаходить Gemini цього гравця в його світі (зайві копії прибирає). */
    public static GeminiEntity find(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.level;
        List<Entity> list = world.getEntities(GeminiMod.GEMINI.get(),
                e -> e instanceof GeminiEntity && player.getUUID().equals(((GeminiEntity) e).getOwnerUUID()));
        if (list.isEmpty()) return null;
        for (int i = 1; i < list.size(); i++) {
            list.get(i).remove();
        }
        return (GeminiEntity) list.get(0);
    }

    public static GeminiEntity spawnFor(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.level;
        GeminiEntity g = GeminiMod.GEMINI.get().create(world);
        if (g == null) return null;
        g.moveTo(player.getX(), player.getY(), player.getZ(), player.yRot, 0.0F);
        g.tame(player);
        world.addFreshEntity(g);
        return g;
    }

    public static GeminiEntity ensure(ServerPlayerEntity player) {
        GeminiEntity g = find(player);
        return g != null ? g : spawnFor(player);
    }

    public static void teleportToPlayer(GeminiEntity g, ServerPlayerEntity player) {
        g.moveTo(player.getX(), player.getY(), player.getZ(), player.yRot, 0.0F);
        g.getNavigation().stop();
    }

    public static void run(ServerPlayerEntity player, int cmd) {
        GeminiEntity g = ensure(player);
        if (g == null) return;

        if (cmd == FOLLOW || cmd == STAY || cmd == COME || cmd == ATTACK) {
            g.stopMining();
        }

        switch (cmd) {
            case FOLLOW:
                g.setOrderedToSit(false);
                say(player, "Іду за тобою!");
                break;
            case STAY:
                g.setOrderedToSit(true);
                say(player, "Стою тут і чекаю.");
                break;
            case COME:
                teleportToPlayer(g, player);
                say(player, "Я вже біля тебе!");
                break;
            case ATTACK:
                if (g.attackNearest()) {
                    say(player, "Атакую!");
                } else {
                    say(player, "Ворогів поруч не бачу.");
                }
                break;
            case GIVE_ITEM: {
                ItemStack held = player.getMainHandItem();
                if (held.isEmpty()) {
                    say(player, "Візьми предмет у руку, і я його візьму.");
                    break;
                }
                ItemStack one = held.copy();
                one.setCount(1);
                EquipmentSlotType slot = MobEntity.getEquipmentSlotForItem(one);
                ItemStack old = g.getItemBySlot(slot);
                if (!old.isEmpty()) {
                    g.spawnAtLocation(old);
                }
                g.setItemSlot(slot, one);
                if (!player.abilities.instabuild) {
                    held.shrink(1);
                }
                say(player, "Дякую! Беру це з собою.");
                break;
            }
            case TAKE_BACK: {
                boolean any = false;
                for (EquipmentSlotType slot : EquipmentSlotType.values()) {
                    ItemStack st = g.getItemBySlot(slot);
                    if (!st.isEmpty()) {
                        g.spawnAtLocation(st);
                        g.setItemSlot(slot, ItemStack.EMPTY);
                        any = true;
                    }
                }
                say(player, any ? "Віддаю все спорядження." : "У мене нічого немає.");
                break;
            }
            case FIND_ORES:
                findOres(player);
                break;
            case MINE_ORES:
                g.setOrderedToSit(false);
                g.mineTarget = null;
                g.badTargets.clear();
                g.oreMode = true;
                say(player, "Іду копати руди!");
                break;
            case MINE_LOOKED: {
                RayTraceResult r = player.pick(30.0D, 1.0F, false);
                if (r.getType() == RayTraceResult.Type.BLOCK) {
                    g.setOrderedToSit(false);
                    g.oreMode = false;
                    g.badTargets.clear();
                    g.mineTarget = ((BlockRayTraceResult) r).getBlockPos();
                    say(player, "Копаю цей блок!");
                } else {
                    say(player, "Я не бачу блока, на який ти дивишся.");
                }
                break;
            }
            case STOP_MINING:
                g.stopMining();
                say(player, "Гаразд, більше не копаю.");
                break;
            default:
                break;
        }
    }

    private static void findOres(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.level;
        Map<Block, int[]> found = OreFinder.scan(world, player.blockPosition(), 32);
        if (found.isEmpty()) {
            say(player, "У радіусі 32 блоків руд не знайшов.");
            return;
        }
        List<Map.Entry<Block, int[]>> list = new ArrayList<>(found.entrySet());
        list.sort((a, b) -> Integer.compare(a.getValue()[4], b.getValue()[4]));

        say(player, "Знайшов руди поруч:");
        int shown = 0;
        for (Map.Entry<Block, int[]> e : list) {
            if (shown++ >= 12) break;
            int[] v = e.getValue();
            IFormattableTextComponent line = new StringTextComponent("\u00a77 - \u00a7r")
                    .append(e.getKey().getName())
                    .append(new StringTextComponent(": " + v[0] + " шт., найближча X=" + v[1]
                            + " Y=" + v[2] + " Z=" + v[3] + " (" + (int) Math.sqrt(v[4]) + " бл.)"));
            player.sendMessage(line, Util.NIL_UUID);
        }
    }
}
