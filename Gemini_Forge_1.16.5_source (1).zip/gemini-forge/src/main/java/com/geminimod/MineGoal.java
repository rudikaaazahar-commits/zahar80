package com.geminimod;

import java.util.EnumSet;

import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.pathfinding.Path;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Gemini копає: йде до цілі, а якщо дороги нема - прокладає тунель. */
public class MineGoal extends Goal {
    private final GeminiEntity g;
    private int cooldown = 0;
    private int attempts = 0;

    public MineGoal(GeminiEntity g) {
        this.g = g;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    private boolean active() {
        LivingEntity target = g.getTarget();
        boolean fighting = target != null && target.isAlive();
        return g.isTame() && !fighting && (g.mineTarget != null || g.oreMode);
    }

    @Override
    public boolean canUse() {
        return active();
    }

    @Override
    public boolean canContinueToUse() {
        return active();
    }

    private void tell(String text) {
        LivingEntity owner = g.getOwner();
        if (owner instanceof ServerPlayerEntity) {
            GeminiCommands.say((ServerPlayerEntity) owner, text);
        }
    }

    @Override
    public void tick() {
        if (--cooldown > 0) return;
        cooldown = 6;
        World w = g.level;

        if (g.mineTarget == null) {
            g.mineTarget = OreFinder.findNearest(w, g.blockPosition(), 20, g.badTargets);
            attempts = 0;
            if (g.mineTarget == null) {
                g.oreMode = false;
                tell("Руд поруч більше немає, я закінчив.");
                return;
            }
        }

        BlockPos t = g.mineTarget;
        BlockState st = w.getBlockState(t);
        if (st.isAir(w, t)) {
            g.mineTarget = null;
            return;
        }

        if (++attempts > 300) {
            g.badTargets.add(t);
            g.mineTarget = null;
            attempts = 0;
            return;
        }

        double cx = t.getX() + 0.5D, cy = t.getY() + 0.5D, cz = t.getZ() + 0.5D;
        g.getLookControl().setLookAt(cx, cy, cz);

        if (g.distanceToSqr(cx, cy, cz) <= 12.0D) {
            mineTarget(w, t, st);
            return;
        }

        Path path = g.getNavigation().createPath(t, 1);
        if (path != null && path.canReach()) {
            g.getNavigation().moveTo(path, 1.2D);
            return;
        }
        digStep(w, t);
    }

    private void mineTarget(World w, BlockPos t, BlockState st) {
        if (st.getDestroySpeed(w, t) < 0 || st.hasTileEntity()) {
            g.badTargets.add(t);
            g.mineTarget = null;
            return;
        }
        g.swing(Hand.MAIN_HAND);
        w.destroyBlock(t, true, g);
        bringDrops(w, t);
        g.mineTarget = null;
        attempts = 0;
    }

    /** Здобич, що випала, відправляємо власнику. */
    private void bringDrops(World w, BlockPos t) {
        LivingEntity owner = g.getOwner();
        if (owner == null) return;
        for (ItemEntity item : w.getEntitiesOfClass(ItemEntity.class, new AxisAlignedBB(t).inflate(2.0D))) {
            item.setDeltaMovement(0.0D, 0.0D, 0.0D);
            item.setPos(owner.getX(), owner.getY(), owner.getZ());
        }
    }

    private boolean unsafe(World w, BlockPos p) {
        BlockState bs = w.getBlockState(p);
        if (bs.getDestroySpeed(w, p) < 0 || bs.hasTileEntity()) return true;
        if (!w.getFluidState(p).isEmpty()) return true;
        for (Direction d : Direction.values()) {
            if (!w.getFluidState(p.relative(d)).isEmpty()) return true;
        }
        return false;
    }

    /** Один крок тунелю до цілі: ламаємо 2 блоки і ставимо Gemini туди. */
    private void digStep(World w, BlockPos t) {
        BlockPos pos = g.blockPosition();
        int dx = t.getX() - pos.getX();
        int dy = t.getY() - pos.getY();
        int dz = t.getZ() - pos.getZ();
        int sx = 0, sz = 0;
        if (dx != 0 && Math.abs(dx) >= Math.abs(dz)) {
            sx = Integer.signum(dx);
        } else if (dz != 0) {
            sz = Integer.signum(dz);
        } else if (dx != 0) {
            sx = Integer.signum(dx);
        } else {
            sz = 1;
        }
        int sy = Integer.signum(dy);

        BlockPos n = pos.offset(sx, sy, sz);
        BlockPos head = n.above();
        if (unsafe(w, n) || unsafe(w, head)) {
            g.badTargets.add(t);
            g.mineTarget = null;
            attempts = 0;
            tell("Туди копати небезпечно (рідина або міцний блок), пропускаю.");
            return;
        }
        if (!w.getBlockState(n).isAir(w, n)) w.destroyBlock(n, false, g);
        if (!w.getBlockState(head).isAir(w, head)) w.destroyBlock(head, false, g);
        g.swing(Hand.MAIN_HAND);
        g.moveTo(n.getX() + 0.5D, n.getY(), n.getZ() + 0.5D, g.yRot, 0.0F);
        g.getNavigation().stop();
    }

    @Override
    public void stop() {
        attempts = 0;
    }
}
