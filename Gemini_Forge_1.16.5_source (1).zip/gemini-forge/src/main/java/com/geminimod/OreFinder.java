package com.geminimod;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.Tags;

public class OreFinder {

    public static boolean isOre(BlockState state) {
        return state.is(Tags.Blocks.ORES) || state.is(Blocks.ANCIENT_DEBRIS);
    }

    /** Найближча руда в кубі з радіусом r (пропускає "погані" цілі). */
    public static BlockPos findNearest(World world, BlockPos center, int r, Set<BlockPos> bad) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    m.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                    if (m.getY() < 0 || m.getY() > 255 || !world.hasChunkAt(m)) continue;
                    if (!isOre(world.getBlockState(m))) continue;
                    if (bad.contains(m)) continue;
                    double d = x * x + y * y + z * z;
                    if (d < bestDist) {
                        bestDist = d;
                        best = m.immutable();
                    }
                }
            }
        }
        return best;
    }

    /** Усі руди в радіусі r: блок -> {кількість, x, y, z найближчої, відстань^2}. */
    public static Map<Block, int[]> scan(World world, BlockPos center, int r) {
        Map<Block, int[]> found = new HashMap<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    m.set(center.getX() + x, center.getY() + y, center.getZ() + z);
                    if (m.getY() < 0 || m.getY() > 255 || !world.hasChunkAt(m)) continue;
                    BlockState s = world.getBlockState(m);
                    if (!isOre(s)) continue;
                    int d = x * x + y * y + z * z;
                    int[] e = found.get(s.getBlock());
                    if (e == null) {
                        found.put(s.getBlock(), new int[]{1, m.getX(), m.getY(), m.getZ(), d});
                    } else {
                        e[0]++;
                        if (d < e[4]) {
                            e[1] = m.getX(); e[2] = m.getY(); e[3] = m.getZ(); e[4] = d;
                        }
                    }
                }
            }
        }
        return found;
    }
}
