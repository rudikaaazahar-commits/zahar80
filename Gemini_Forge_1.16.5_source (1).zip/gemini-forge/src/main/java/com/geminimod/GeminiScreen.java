package com.geminimod;

import com.mojang.blaze3d.matrix.MatrixStack;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.StringTextComponent;

public class GeminiScreen extends Screen {
    private static final String[] NAMES = {
            "Іди за мною",
            "Стій тут",
            "Приходь до мене",
            "Атакуй ворога",
            "Дати предмет з руки",
            "Забрати спорядження",
            "Знайти руди",
            "Копати руди",
            "Копати блок, куди дивлюсь",
            "Стоп копання"
    };

    public GeminiScreen() {
        super(new StringTextComponent("Gemini"));
    }

    @Override
    protected void init() {
        int rows = 5;
        int top = this.height / 2 - (rows * 24) / 2;
        for (int i = 0; i < NAMES.length; i++) {
            final int id = i;
            int col = i / rows;
            int row = i % rows;
            int x = this.width / 2 - 155 + col * 160;
            this.addButton(new Button(x, top + row * 24, 150, 20,
                    new StringTextComponent(NAMES[i]), b -> {
                        Net.CHANNEL.sendToServer(new CommandPacket(id));
                        this.onClose();
                    }));
        }
    }

    @Override
    public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(ms);
        drawCenteredString(ms, this.font, "Gemini - команди",
                this.width / 2, this.height / 2 - 78, 0xFFFFFF);
        super.render(ms, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == ClientSetup.OPEN_MENU.getKey().getValue()) {
            this.onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
