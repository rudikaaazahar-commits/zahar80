package com.geminimod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GeminiMod.MODID)
public class GeminiEvents {
    /** Чекаємо ~3 секунди після входу, щоб світ навколо гравця встиг завантажитись. */
    private static final Map<UUID, Integer> PENDING = new HashMap<>();

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getPlayer() instanceof ServerPlayerEntity) {
            PENDING.put(event.getPlayer().getUUID(), 60);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER || PENDING.isEmpty()) return;
        UUID id = event.player.getUUID();
        Integer t = PENDING.get(id);
        if (t == null) return;
        if (t > 1) {
            PENDING.put(id, t - 1);
            return;
        }
        PENDING.remove(id);
        if (!(event.player instanceof ServerPlayerEntity)) return;

        ServerPlayerEntity player = (ServerPlayerEntity) event.player;
        GeminiEntity g = GeminiCommands.find(player);
        if (g == null) {
            g = GeminiCommands.spawnFor(player);
        } else {
            GeminiCommands.teleportToPlayer(g, player);
        }
        if (g != null) {
            GeminiCommands.say(player, "Підключився до сервера! Натисни F4, щоб керувати мною.");
        }
    }
}
