GEMINI COMPANION - Forge 1.16.5

ГОТОВИЙ .JAR БЕЗ ПК - через GitHub (див. файл build.yml поруч з архівом):
1. На github.com створи новий репозиторій.
2. Add file -> Upload files -> завантаж цей zip.
3. Add file -> Create new file -> назва  .github/workflows/build.yml  -> встав вміст build.yml -> Commit.
4. Вкладка Actions -> дочекайся зеленої галочки (5-10 хв) -> відкрий запуск -> внизу Artifacts -> geminimod-jar.
5. У скачаному архіві буде geminimod-1.0.0.jar -> кинь у папку mods (Minecraft 1.16.5 + Forge 36.2.39).

АБО НА ПК (JDK 8, Forge MDK 1.16.5-36.2.39): заміни build.gradle і src, запусти gradlew build.

В ГРІ:
- Заходиш у світ -> Gemini з'являється біля тебе.
- F4 -> меню: іди за мною / стій / до мене / атакуй / дати предмет / забрати спорядження /
  знайти руди / копати руди / копати блок, куди дивлюсь / стоп копання.
